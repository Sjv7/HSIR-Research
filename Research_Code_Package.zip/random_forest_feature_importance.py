# random_forest_feature_importance.py
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

def feature_importance(X, y):
    model = RandomForestRegressor(random_state=42)
    model.fit(X, y)
    return model.feature_importances_

if __name__ == "__main__":
    X = pd.DataFrame({'sentiment_score': [0.1, 0.4, 0.2, 0.5], 'volume': [1000, 1500, 1200, 1300]})
    y = [0.01, 0.03, -0.02, 0.04]
    importance = feature_importance(X, y)
    print(importance)
