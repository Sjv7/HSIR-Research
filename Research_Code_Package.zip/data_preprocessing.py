# data_preprocessing.py
import pandas as pd

def clean_text(text):
    import re
    text = text.lower()
    text = re.sub(r"http\S+|www\S+|https\S+", '', text)
    text = re.sub(r'[^A-Za-z\s]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def preprocess_data(news_file, stock_file):
    news_df = pd.read_csv(news_file)
    stock_df = pd.read_csv(stock_file)
    news_df['cleaned_headline'] = news_df['headline'].apply(clean_text)
    return news_df, stock_df

if __name__ == "__main__":
    news, stocks = preprocess_data('news.csv', 'stocks.csv')
    print(news.head())
