# finbert_sentiment.py
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

def get_finbert_sentiment(texts):
    tokenizer = AutoTokenizer.from_pretrained('yiyanghkust/finbert-tone')
    model = AutoModelForSequenceClassification.from_pretrained('yiyanghkust/finbert-tone')
    inputs = tokenizer(texts, return_tensors='pt', truncation=True, padding=True)
    outputs = model(**inputs)
    scores = torch.nn.functional.softmax(outputs.logits, dim=1)
    return scores.detach().numpy()

if __name__ == "__main__":
    sample_texts = ["Markets are crashing due to global tensions."]
    sentiments = get_finbert_sentiment(sample_texts)
    print(sentiments)
