# lda_topic_modeling.py
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation

def lda_topics(texts, n_topics=5):
    vectorizer = CountVectorizer(max_df=0.95, min_df=2, stop_words='english')
    X = vectorizer.fit_transform(texts)
    lda = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda.fit(X)
    return lda, vectorizer

if __name__ == "__main__":
    docs = ["Stocks rally on strong earnings", "Oil prices drop amid supply fears"]
    model, vec = lda_topics(docs)
    print(model.components_)
